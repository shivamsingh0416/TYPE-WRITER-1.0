HOW TO GET YOUR APK

Option A - on phone (GitHub Actions)
1. Create a new GitHub repository.
2. Upload ALL files from this folder to it.
3. If the .github folder did not upload, on GitHub tap Add file > Create new file,
   type  .github/workflows/build.yml  as the name, and paste the text from BUILD-WORKFLOW.yml.
4. Open the Actions tab, wait for the green tick, open the run,
   and download app-debug-apk from Artifacts. Unzip it to get app-debug.apk.

Option B - on PC (Android Studio)
1. Open this folder in Android Studio and wait for Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).

Notes
- Your web files are in app/src/main/assets/www/
- Change them any time and build again.
- This makes a debug APK. It installs fine, but is not signed for Play Store.
- Browser-style downloads (like saving a PNG) may not work inside a WebView app.
